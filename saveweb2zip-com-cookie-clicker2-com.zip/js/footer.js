$(document).ready(function () {
    expand();
    add_plugin();
    $(".hidden__left").on('click', function () {
        if ($(this).hasClass('active__left')) {
            $(this).removeClass("active__left");
            $(".gridbody__left").removeClass("hide__left");
        } else {
            $(this).addClass("active__left");
            $(".gridbody__left").addClass("hide__left");
        }

    })
})

function add_plugin() {
    let url = "/add-plugin.ajax";
    if (typeof id_game != 'undefined' && id_game != '') {
        $.ajax({
            type: "POST",
            url: url,
            data: {id: id_game},
            success: function (data) {
                if (data) {
                    let html = JSON.parse(data);
                    if (html.html_rate) {
                        $("#append-rate").html(html.html_rate);
                    }
                }
            }
        });
    }
}

function expand() {
    $("#expand").on('click', function () {
        $("#_exit_full_screen").removeClass('hidden');
        $("#iframehtml5").addClass("force_full_screen");
        requestFullScreen(document.body);
    });
    $("#_exit_full_screen").on('click', cancelFullScreen);
}
function paging(p) {
    $(".gif").removeClass("hidden");
    let url = '/paging.ajax';
    let current_url = location.origin + location.pathname;
    $.ajax({
        type: "POST",
        url: url,
        data: {
            page: p,
            keywords: keywords,
            tags_id: tag_id,
            category_id: category_id,
            field_order: field_order,
            order_type: order_type,
            is_hot: is_hot,
            is_new: is_new,
            limit: limit
        },
        success: function (xxxx) {
            $("html, body").animate({scrollTop: 0}, 0);
            $(".gif").addClass("hidden");
            if (xxxx !== '') {
                let data = JSON.parse(xxxx);
                $("#ajax-append").html(data.content);
            }
        }
    });
}

function runValidate() {
    jQuery("#contact-form").validate({
        focusInvalid: false,
        onfocusout: false,
        ignore: ".ignore",
        rules: {
            Name: {
                required: true,
                maxlength: 255,
            },
            Email: {
                required: true,
                email: true,
                maxlength: 100
            },
            Website: {
                required: false,
                maxlength: 255,
            },
            Topic: {
                required: false,
                maxlength: 255,
            },
            Message: {
                required: true,
                maxlength: 65525
            },
            "hiddenRecaptcha": {
                required: function () {
                    if (grecaptcha.getResponse() == '') {
                        return true;
                    } else {
                        return false;
                    }
                }
            }
        },
        messages: {
            Name: {
                required: "Please type your name!",
                maxlength: "255"
            },
            Email: {
                required: "Please type your email!",
                email: "Please check a valid email!",
                maxlength: "100"
            },
            Message: {
                required: "Please type your message!",
                maxlength: "65525"
            },
            "hiddenRecaptcha": {
                required: "Please verify you are human!",
            }
        },
        submitHandler: function () {
            $("#fcf-button").prop('disabled', true);
            let question_ajax = "/make-contact.ajax";
            let name = jQuery("#Name").val();
            let email = jQuery("#Email").val();
            let website = jQuery("#Website").val();
            let subject = jQuery("#Topic").val();
            let message = jQuery("#Message").val();
            if (sessionStorage.getItem('contact_message') == message.trim()) {
                alert("Message not sent with the same content.");
                return;
            }
            let metadataload = {};
            metadataload.name = name;
            metadataload.email = email;
            metadataload.website = website;
            metadataload.subject = subject;
            metadataload.message = message;
            sessionStorage.setItem('contact_message', message.trim());
            jQuery.ajax({
                url: question_ajax,
                data: metadataload,
                type: 'POST',
                success: function (data) {
                    if (data != 0 || data != '0') {
                        showSuccessMessage();
                    }
                }
            });
        }
    });
}
function scrollToDiv(element) {
    if ($(element).length) {
        $('html,body').animate({scrollTop: $(element).offset().top - 100}, 'slow');
    }
}
function closeBox() {
    $(".close-sharing-box").hide();
    $(".clipboard-share").addClass("hide-zindex");
}

function showSharingBox() {
    $(".close-sharing-box").show();
    $(".clipboard-share").removeClass("hide-zindex");
}
function showSuccessMessage(message) {
    document.getElementById('fcf-status').innerHTML = '';
    document.getElementById('fcf-form').style.display = 'none';
    document.getElementById('fcf-thank-you').style.display = 'block';
}

function resetFormDemo() {
    document.getElementById('fcf-form').style.display = "block";
    document.getElementById('fcf-thank-you').style.display = "none";
}

function copyToClipboard(element) {
    var $temp = $("<input>");
    $("body").append($temp);
    $temp.val($(element).attr('href')).select();
    document.execCommand("copy");
    $temp.remove();
}
function requestFullScreen(element) {
    // Supports most browsers and their versions.
    var requestMethod = element.requestFullScreen || element.webkitRequestFullScreen || element.mozRequestFullScreen || element.msRequestFullScreen;

    if (requestMethod) { // Native full screen.
        requestMethod.call(element);
    } else if (typeof window.ActiveXObject !== "undefined") { // Older IE.
        var wscript = new ActiveXObject("WScript.Shell");
        if (wscript !== null) {
            wscript.SendKeys("{F11}");
        }
    }
}

function cancelFullScreen() {
    $("#_exit_full_screen").addClass('hidden');
    $("#iframehtml5").removeClass("force_full_screen");
    var requestMethod = document.cancelFullScreen || document.webkitCancelFullScreen || document.mozCancelFullScreen || document.exitFullScreenBtn;
    if (requestMethod) { // cancel full screen.
        requestMethod.call(document);
    } else if (typeof window.ActiveXObject !== "undefined") { // Older IE.
        var wscript = new ActiveXObject("WScript.Shell");
        if (wscript !== null) {
            wscript.SendKeys("{F11}");
        }
    }
}

if (document.addEventListener) {
    document.addEventListener('webkitfullscreenchange', exitHandler, false);
    document.addEventListener('mozfullscreenchange', exitHandler, false);
    document.addEventListener('fullscreenchange', exitHandler, false);
    document.addEventListener('MSFullscreenChange', exitHandler, false);
}

function exitHandler() {
    if (document.webkitIsFullScreen === false
            || document.mozFullScreen === false
            || document.msFullscreenElement === false) {
        cancelFullScreen();
    }
}